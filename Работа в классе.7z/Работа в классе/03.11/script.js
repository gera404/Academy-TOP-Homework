function colorCh1(e){
    d4.style.background = `greenyellow`
    
}
function colorCh2(e){
    d4.style.background = `yellow`
    
}
function colorCh3(e){
    d4.style.background = `red`
    
}